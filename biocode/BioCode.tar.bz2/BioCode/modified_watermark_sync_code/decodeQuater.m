function m = decodeQuater(quater)

% Copyright (C) 2013 David Haughton and Félix Balado
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.  
  
m=blanks(length(quater)*2);

for i =1:length(quater)
   
    temp = dec2bin(str2num(quater(i)));
    if length(temp)==1
       temp= ['0' temp];
    end
    index = (i*2)-1;
    m(index:index+1)=temp;
end

end