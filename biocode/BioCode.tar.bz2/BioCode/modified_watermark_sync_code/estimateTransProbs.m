function [transitions transversions]  = estimateTransProbs(watermarker, z,positions)

% Copyright (C) 2013 David Haughton and Félix Balado
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.  
  
  
% {A, C, T, G} \mapsto {0, 1, 2, 3}
waterposes = [1:1:length(z)];
waterposes(positions) = [];
recieved = z(waterposes);
watermarker=watermarker(waterposes);

transitions =0;
transversions = 0;

for i =1:length(recieved)
   if ~strcmp(recieved(i) ,watermarker(i))
        if strcmp(watermarker(i),'0')
            if strcmp(recieved(i),'3')
                transitions=transitions+1;
            else
                transversions = transversions +1;
            end
        elseif strcmp(watermarker(i),'1')
            if strcmp(recieved(i),'2')
                transitions=transitions+1;
            else
                transversions = transversions +1;
            end
        elseif strcmp(watermarker(i),'2')
            if strcmp(recieved(i),'1')
                transitions=transitions+1;
            else
                transversions = transversions +1;
            end
        elseif strcmp(watermarker(i),'3')
            if strcmp(recieved(i),'0')
                transitions=transitions+1;
            else
                transversions = transversions +1;
            end
        end
   end
end

if transversions==0&&transitions==0
    transitions = 8;
   transversions=1; 
elseif transversions==0
   transversions=transitions/8; 
elseif transitions==0
   transitions=8*transversions; 
end

end