function encoded = encodeLDPC(m,G)

% Copyright (C) 2013 David Haughton and Félix Balado
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.  
  
[s1 s2]=size(G);

encoded='';

% for i=1:s1:length(m)-s2+1
for i=1:s1:length(m)-s1+1
    temp = zeros(1,s1); 
    for j =0:s1-1
       temp(j+1)=str2num(m(i+j));
    end
    
    coded = gf(temp,2)*G;
    coded=coded.x;
    
    for k=1:length(coded)
        encoded= [encoded num2str(coded(k))];
    end
    
end

end