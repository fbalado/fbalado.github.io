function y=permutation_encoding(x,m)
% PERMUTATION_ENCODING - Unranks (encodes) permutation.
%    Y=PERMUTATION_ENCODING(X,M) returns the permutation Y with
%    histogram H=HISTC(X,V), with V=UNIQUE(X), whose rank is given by the 
%    bit sequence M.
%                       
%    In steganography: NBITS=LENGTH(M) must be <= LOG2_MULTINOMIAL(H) in 
%    order to guarantee unique decoding.
%  
%    See also: PERMUTATION_DECODING, LOG2_MULTINOMIAL.
  
% $Id: permutation_encoding.m,v 1.2 2014/10/17 10:48:52 felix Exp $  