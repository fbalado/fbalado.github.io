function m=permutation_decoding(y,nbits)
% PERMUTATION_DECODING - Ranks (decodes) permutation.
%   M=PERMUTATION_DECODING(Y,NBITS) returns the rank of Y as a
%   bit sequence M of length NBITS                       
%                       
%   In steganography: NBITS=FLOOR(LOG2_MULTINOMIAL(H)), where H=HISTC(Y,V) and
%   V=UNIQUE(Y), in order to guarantee unique decoding.
%
%   See also: PERMUTATION_ENCODING, LOG2_MULTINOMIAL.

% $Id: permutation_decoding.m,v 1.3 2014/09/13 14:40:14 felix Exp $ 