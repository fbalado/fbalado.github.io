% test optimum EHS and inverse (reconstruction)

% histogram equalisation (flat target histogram, results in paper)
% random approach

% % 256x256
hs('chemical.png','',1); 
hs('clock.png','',1); 
hs('elaine.png','',1); 
hs('moon.png','',1); 
hs('tree.png','',1); 
hs('trui.png','',1); 

% 512x512
hs('aerial.png','',1); 
hs('airplane.png','',1); 
hs('boat.png','',1); 
hs('mandrill.png','',1); 
hs('raffia.png','',1); 
hs('stream.png','',1); 

% 1024x1024
hs('bark.png','',1); 
hs('man.png','',1); 
hs('pentagon.png','',1); 
hs('smarties.png','',1); 
hs('stones.png','',1); 
hs('traffic.png','',1); 

% 2048x2048
hs('eifel.png','',1); 
hs('boys.png','',1); 
hs('plants.png','',1); 
hs('pont.png','',1); 
hs('church.png','',1); 
hs('violine.png','',1); 

