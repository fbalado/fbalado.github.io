% test optimum EHS and inverse (reconstruction)

% histogram equalisation (flat target histogram, results in paper)

% % 256x256
hs('chemical.png'); 
hs('clock.png'); 
hs('elaine.png'); 
hs('moon.png'); 
hs('tree.png'); 
hs('trui.png'); 

% 512x512
hs('aerial.png'); 
hs('airplane.png'); 
hs('boat.png'); 
hs('mandrill.png'); 
hs('raffia.png'); 
hs('stream.png'); 

% 1024x1024
hs('bark.png'); 
hs('man.png'); 
hs('pentagon.png'); 
hs('smarties.png'); 
hs('stones.png'); 
hs('traffic.png'); 

% 2048x2048
hs('eifel.png'); 
hs('boys.png'); 
hs('plants.png'); 
hs('pont.png'); 
hs('church.png'); 
hs('violine.png'); 

