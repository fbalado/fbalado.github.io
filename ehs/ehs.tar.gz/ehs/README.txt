The Matlab files in this directory implement the algorithms and theoretical
expressions from the paper "EXACT HISTOGRAM SPECIFICATION AND
PERMUTATION CODES", by Félix Balado

hs.m is the main file (optimum exact histogram specification,
reconstruction using random and stable approaches, theoretical results
& display of images)

You can see how the main file works by running the test programs
below, which use a small database of 24 images (same ones used in the paper).

hs_test_eq.m: histogram equalisation (+reconstruction using stable approach)
hs_test_eq_r.m: histogram equalisation (+reconstruction using random approach)

The two files above reproduce all the results in the paper. The two
files below are extra tests using non-flat histograms.

hs_test_ehs.m: exact histogram specification (+reconstruction using stable approach)
hs_test_ehs_r.m: exact histogram specification  (+reconstruction using random approach)

(when running any of these programs, just close a figure window to move on
to the next example)

Acknowledgements:
- Thank you to Mila Nikolova for the image database
- Thank you to Nikolay S. for subplot_tight.m 

Félix Balado (felix@ucd.ie)
January 2017
