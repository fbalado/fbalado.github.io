% test optimum EHS and inverse (reconstruction)

% test cases where the histogram of one image is given to another one

% 256x256
hs('chemical.png','clock.png'); 
hs('elaine.png','moon.png'); 
hs('tree.png','trui.png'); 

% 512x512
hs('aerial.png','airplane.png'); 
hs('boat.png','mandrill.png'); 
hs('raffia.png','stream.png'); 

% 1024x1024
hs('bark.png','man.png'); 
hs('pentagon.png','smarties.png'); 
hs('stones.png','traffic.png'); 

% 2048x2048
hs('eifel.png','boys.png');
hs('plants.png','pont.png'); 
hs('church.png','violine.png'); 
