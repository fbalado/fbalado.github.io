% test optimum EHS and inverse (reconstruction)

% test cases where the histogram of one image is given to another one
% random approach

% 256x256
hs('chemical.png','clock.png',1); 
hs('elaine.png','moon.png',1); 
hs('tree.png','trui.png',1); 

% 512x512
hs('aerial.png','airplane.png',1); 
hs('boat.png','mandrill.png',1); 
hs('raffia.png','stream.png',1); 

% 1024x1024
hs('bark.png','man.png',1); 
hs('pentagon.png','smarties.png',1); 
hs('stones.png','traffic.png',1); 

% 2048x2048
hs('eifel.png','boys.png',1);
hs('plants.png','pont.png',1); 
hs('church.png','violine.png',1); 
